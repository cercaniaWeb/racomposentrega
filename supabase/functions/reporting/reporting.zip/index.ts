// reporting - instrumented Edge Function
// Deploy as "reporting". Uses Deno.serve
console.info('reporting function starting');
Deno.serve(async (req)=>{
  const start = Date.now();
  const url = new URL(req.url);
  const requestId = crypto.randomUUID();
  // Helper to build JSON responses
  const json = (obj, status = 200)=>new Response(JSON.stringify(obj), {
      status,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  try {
    // Basic request metadata
    const meta = {
      id: requestId,
      method: req.method,
      path: url.pathname,
      query: Object.fromEntries(url.searchParams.entries()),
      forwardedFor: req.headers.get('x-forwarded-for'),
      userAgent: req.headers.get('user-agent'),
      time: new Date().toISOString()
    };
    // Read body safely with size limit (e.g., 1MB)
    const MAX_BYTES = 1 * 1024 * 1024;
    const contentLength = Number(req.headers.get('content-length') || '0');
    if (contentLength > MAX_BYTES) {
      console.error(`[${requestId}] Payload too large: ${contentLength}`);
      return json({
        error: 'Payload too large'
      }, 413);
    }
    const rawBody = await req.text();
    let body = null;
    if (rawBody) {
      try {
        body = JSON.parse(rawBody);
      } catch (err) {
        console.error(`[${requestId}] Invalid JSON body`, {
          error: String(err),
          rawBody
        });
        return json({
          error: 'Invalid JSON body',
          details: String(err)
        }, 400);
      }
    }
    // Log incoming request (minimal; avoid logging secrets)
    console.info(`[${requestId}] Incoming request`, {
      meta,
      bodyPreview: typeof body === 'object' ? JSON.stringify(body).slice(0, 200) : String(body).slice(0, 200),
      headers: {
        authorization: req.headers.get('authorization') ? 'present' : 'missing',
        'content-type': req.headers.get('content-type')
      }
    });
    // Example: validate required fields expected by reporting
    // Adjust these checks to match your real schema
    if (!body || !body.reportType) {
      console.warn(`[${requestId}] Missing reportType in body`);
      return json({
        error: 'Missing reportType in body',
        expected: {
          reportType: 'string'
        }
      }, 400);
    }
    // Example: perform DB call if needed (optional)
    // If you plan to use SUPABASE_SERVICE_ROLE_KEY or SUPABASE_DB_URL, ensure env vars are set.
    // Uncomment and adjust the following when you need DB access.
    /*
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      console.error(`[${requestId}] Missing SUPABASE env vars`);
      return json({ error: 'Server misconfiguration: missing SUPABASE credentials' }, 500);
    }
    // Example simple fetch to Supabase REST (adjust to your endpoint)
    const resp = await fetch(`${SUPABASE_URL}/rest/v1/some_table?select=*`, {
      headers: { apikey: SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
    });
    if (!resp.ok) {
      const txt = await resp.text();
      console.error(`[${requestId}] Supabase REST error`, { status: resp.status, body: txt });
      return json({ error: 'DB error', details: txt }, 502);
    }
    const rows = await resp.json();
    */ // Placeholder: implement real report logic here
    const result = {
      requestId,
      reportType: body.reportType,
      message: `Received report request of type ${body.reportType}`
    };
    const duration = Date.now() - start;
    console.info(`[${requestId}] Success`, {
      durationMs: duration
    });
    return json({
      ok: true,
      result,
      meta
    }, 200);
  } catch (err) {
    // Capture stack trace and return minimal safe message
    console.error(`[${requestId}] Internal error`, {
      error: String(err),
      stack: err?.stack
    });
    return new Response(JSON.stringify({
      error: 'Internal Server Error',
      details: err?.message,
      requestId
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
});
